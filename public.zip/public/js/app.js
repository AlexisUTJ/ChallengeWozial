window.addEventListener('load', function(){
new Glider(document.querySelector('.ContCardsSeccion2'), {
    slidesToShow: 4,
    slidesToScroll: 4,
    draggable: true,
    dots: '.carousel_indicadores',
    arrows: {
      prev: '.btnAnterior',
      next: '.btnSiguiente'
    },
    responsive: [
      {
        // screens greater than >= 1024px
        breakpoint: 1367,
        settings: {
          slidesToShow: 4,
          slidesToScroll: 4,
          itemWidth: 500,
          duration: 0.25
        }
      },
      {
        // screens greater than >= 1024px
        breakpoint: 1024,
        settings: {
          slidesToShow: 3,
          slidesToScroll: 3,
          itemWidth: 150,
          duration: 0.25
        }
      },
        {
          // screens greater than >= 775px
          breakpoint: 775,
          settings: {
            // Set to `auto` and provide item width to adjust to viewport
            slidesToShow: 2,
            slidesToScroll: 2,
            itemWidth: 150,
            duration: 0.25
          }
        },
          {
            // screens greater than >= 500px
            breakpoint: 300,
            settings: {
              slidesToShow: 1,
              slidesToScroll: 1,
              itemWidth: 50,
              duration: 0.25
            }
        }
      ]
});
});

window.addEventListener('load', function(){
    new Glider(document.querySelector('.ContseccionIzqServicios1'), {
        slidesToShow: 1,
        slidesToScroll: 1,
        dots: '.carousel_indicadores1',
        arrows: {
          prev: '.btnAnterior1',
          next: '.btnSiguiente1'
        },
        responsive: [
            {
              // screens greater than >= 775px
              breakpoint: 300,
              settings: {
                // Set to `auto` and provide item width to adjust to viewport
                slidesToShow: '1',
                slidesToScroll: '1',
                itemWidth: 100,
                duration: 0.25
              }
            },{
                // screens greater than >= 775px
                breakpoint: 500,
                settings: {
                  // Set to `auto` and provide item width to adjust to viewport
                  slidesToShow: '1',
                  slidesToScroll: '1',
                  itemWidth: 100,
                  duration: 0.25
                }
              }
            
          ]
    });
    });
    var contador = 1;
    
    function menu(){
      
         if(contador == 1){
          document.getElementById('Ul-Cont-Father').animate({
            rigth:'0%'
          });
          document.getElementById('Ul-Cont-Father').style.right='0%';
          contador =  0;
          console.log("abierto");
         }else{
          document.getElementById('Ul-Cont-Father').animate({
            rigth:'100%'
          });
          contador =  1;
          document.getElementById('Ul-Cont-Father').style.right='100%';
          console.log("cerrado");
         }

      
    }

      var contador3 = 1;
      function btnServiciosMenu(){
            
        if(contador3 == 1){
          document.getElementById('Cont-ul-Head').style.display = "block";
        contador3 =  0;
        console.log("abierto");
        }else{
        contador3 =  1;
        document.getElementById('Cont-ul-Head').style.display = "none";
        console.log("cerrado");
        }
      }
